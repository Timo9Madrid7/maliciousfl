from os import listdir
from os.path import isfile, join

onlyfiles = [f for f in listdir("./greek_preprocessed/train") if isfile(join("./greek_preprocessed/train", f))]

print("####### {}".format(onlyfiles))
